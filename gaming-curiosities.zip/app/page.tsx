"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Gamepad2, Zap, Star, Trophy, Cpu, Headphones, Palette, Building } from "lucide-react"

interface Curiosity {
  title: string
  content: string
  category: string
}

const fallbackCuriosities: Curiosity[] = [
  {
    title: "El primer Easter Egg de la historia",
    content:
      "El primer Easter Egg en un videojuego fue creado por Warren Robinett en 'Adventure' (1979) para Atari 2600. Lo hizo porque Atari no acreditaba a sus programadores, así que escondió su nombre en una habitación secreta del juego.",
    category: "Historia",
  },
  {
    title: "Mario tenía otro nombre",
    content:
      "Mario originalmente se llamaba 'Jumpman' en el juego Donkey Kong (1981). Su nombre cambió a Mario en honor a Mario Segale, el propietario del almacén que Nintendo rentaba en Estados Unidos.",
    category: "Personajes",
  },
  {
    title: "El sonido más caro de la historia",
    content:
      "El sonido de 'SEGA' al inicio de los juegos de Sonic costó $500,000 dólares de producción. Fue grabado por un coro completo y procesado digitalmente para que cupiera en la memoria limitada de la consola.",
    category: "Audio",
  },
]

export default function Component() {
  const [currentCuriosity, setCurrentCuriosity] = useState<Curiosity>(fallbackCuriosities[0])
  const [isLoading, setIsLoading] = useState(false)
  const [lastGenerated, setLastGenerated] = useState<string | null>(null)

  const generateNewCuriosity = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/generate-curiosity", {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to generate curiosity")
      }

      const newCuriosity: Curiosity = await response.json()
      setCurrentCuriosity(newCuriosity)

      // Guardar en localStorage
      localStorage.setItem("lastCuriosity", JSON.stringify(newCuriosity))
      localStorage.setItem("lastGenerated", new Date().toISOString())
      setLastGenerated(new Date().toISOString())
    } catch (error) {
      console.error("Error generating curiosity:", error)
      // Fallback a curiosidad aleatoria si falla la IA
      const randomIndex = Math.floor(Math.random() * fallbackCuriosities.length)
      setCurrentCuriosity(fallbackCuriosities[randomIndex])
    } finally {
      setIsLoading(false)
    }
  }

  const checkDailyCuriosity = async () => {
    const lastGenerated = localStorage.getItem("lastGenerated")
    const today = new Date().toDateString()

    if (!lastGenerated || new Date(lastGenerated).toDateString() !== today) {
      // Generar nueva curiosidad para hoy
      await generateNewCuriosity()
    } else {
      // Cargar curiosidad guardada del día
      const savedCuriosity = localStorage.getItem("lastCuriosity")
      if (savedCuriosity) {
        setCurrentCuriosity(JSON.parse(savedCuriosity))
        setLastGenerated(lastGenerated)
      }
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Historia":
        return <Trophy className="w-5 h-5" />
      case "Personajes":
        return <Star className="w-5 h-5" />
      case "Audio":
        return <Headphones className="w-5 h-5" />
      case "Tecnología":
        return <Cpu className="w-5 h-5" />
      case "Diseño":
        return <Palette className="w-5 h-5" />
      case "Industria":
        return <Building className="w-5 h-5" />
      case "Desarrollo":
        return <Zap className="w-5 h-5" />
      default:
        return <Gamepad2 className="w-5 h-5" />
    }
  }

  useEffect(() => {
    // Verificar si necesitamos generar curiosidad diaria al cargar
    checkDailyCuriosity()

    // Verificar cada hora si cambió el día
    const interval = setInterval(
      () => {
        const lastGenerated = localStorage.getItem("lastGenerated")
        const today = new Date().toDateString()

        if (!lastGenerated || new Date(lastGenerated).toDateString() !== today) {
          generateNewCuriosity()
        }
      },
      60 * 60 * 1000,
    ) // Cada hora

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Elementos decorativos de fondo */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-32 h-32 bg-cyan-500 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-32 w-24 h-24 bg-pink-500 rounded-full blur-lg animate-bounce"></div>
        <div className="absolute bottom-32 left-1/4 w-40 h-40 bg-yellow-500 rounded-full blur-2xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-28 h-28 bg-green-500 rounded-full blur-xl animate-bounce"></div>
      </div>

      {/* Grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `
          linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
        `,
          backgroundSize: "50px 50px",
        }}
      ></div>

      <div className="relative z-10 container mx-auto px-4 py-8 min-h-screen flex flex-col">
        {/* Header */}
        <header className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-2xl">
              <Gamepad2 className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              GameCurious
            </h1>
          </div>
          <p className="text-slate-300 text-lg md:text-xl max-w-2xl mx-auto">
            Descubre datos fascinantes del mundo de los videojuegos generados por IA cada día
          </p>
          {lastGenerated && (
            <p className="text-slate-400 text-sm mt-2">
              Última actualización: {new Date(lastGenerated).toLocaleDateString("es-ES")}
            </p>
          )}
        </header>

        {/* Main Content */}
        <main className="flex-1 flex items-center justify-center">
          <Card
            className={`max-w-4xl w-full bg-slate-800/50 backdrop-blur-lg border-slate-700 shadow-2xl transition-all duration-300 ${
              isLoading ? "scale-95 opacity-50" : "scale-100 opacity-100"
            }`}
          >
            <div className="p-8 md:p-12">
              {/* Category Badge */}
              <div className="flex items-center gap-2 mb-6">
                <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-full border border-cyan-500/30">
                  {getCategoryIcon(currentCuriosity.category)}
                  <span className="text-cyan-300 font-medium">{currentCuriosity.category}</span>
                </div>
                <div className="flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-full border border-green-500/30">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-green-300 text-xs font-medium">IA Generated</span>
                </div>
              </div>

              {/* Title */}
              <h2 className="text-2xl md:text-4xl font-bold text-white mb-6 leading-tight">{currentCuriosity.title}</h2>

              {/* Content */}
              <p className="text-slate-300 text-lg md:text-xl leading-relaxed mb-8">{currentCuriosity.content}</p>

              {/* Action Button */}
              <div className="flex justify-center">
                <Button
                  onClick={generateNewCuriosity}
                  disabled={isLoading}
                  className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold px-8 py-3 rounded-xl text-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:scale-100"
                >
                  <Zap className="w-5 h-5 mr-2" />
                  {isLoading ? "Generando con IA..." : "Nueva Curiosidad IA"}
                </Button>
              </div>
            </div>
          </Card>
        </main>

        {/* Footer */}
        <footer className="text-center mt-12">
          <div className="flex items-center justify-center gap-2 text-slate-400">
            <div className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse"></div>
            <p>Curiosidades generadas por IA • Actualizadas diariamente</p>
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
          </div>
        </footer>
      </div>
    </div>
  )
}
