import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { NextResponse } from "next/server"

export async function POST() {
  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Genera una curiosidad fascinante sobre videojuegos que sea educativa y sorprendente. 
      
      La curiosidad debe:
      - Ser completamente real y verificable
      - Tener entre 100-200 palabras
      - Incluir datos específicos, fechas o números cuando sea posible
      - Ser sobre cualquier aspecto: historia, desarrollo, personajes, tecnología, industria, etc.
      - Ser interesante tanto para gamers casuales como hardcore
      
      Responde SOLO con un JSON en este formato exacto:
      {
        "title": "Título llamativo de la curiosidad",
        "content": "Contenido detallado de la curiosidad con datos específicos",
        "category": "Una de estas categorías: Historia, Personajes, Tecnología, Industria, Desarrollo, Audio, Diseño"
      }`,
      temperature: 0.8,
    })

    // Parse the JSON response
    const curiosity = JSON.parse(text)

    return NextResponse.json(curiosity)
  } catch (error) {
    console.error("Error generating curiosity:", error)
    return NextResponse.json({ error: "Failed to generate curiosity" }, { status: 500 })
  }
}
